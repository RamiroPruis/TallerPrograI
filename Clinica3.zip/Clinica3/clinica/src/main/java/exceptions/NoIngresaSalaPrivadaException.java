package exceptions;

/**
 * Esta excepcion es para cuando no se ingresa a la sala
 */
public class NoIngresaSalaPrivadaException extends Exception {

}
